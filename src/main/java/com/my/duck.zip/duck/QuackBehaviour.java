package com.my.duck;

public interface QuackBehaviour {
	
	void quack();

}
