package com.my.duck;

public interface FlyBehaviour {
	
	void fly();

}
