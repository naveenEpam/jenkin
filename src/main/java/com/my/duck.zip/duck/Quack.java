package com.my.duck;

public class Quack implements QuackBehaviour {

	public void quack() {
		System.out.println("Real Duck");
	}

}
