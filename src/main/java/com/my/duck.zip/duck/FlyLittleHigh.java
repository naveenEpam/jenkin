package com.my.duck;

public class FlyLittleHigh implements FlyBehaviour {

	public void fly() {
		System.out.println("Fly Little High !! Hooray The plastic duck flies.");
		
	}

}
