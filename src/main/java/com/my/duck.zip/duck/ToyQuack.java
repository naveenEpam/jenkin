package com.my.duck;

public class ToyQuack implements QuackBehaviour {

	public void quack() {
		System.out.println("Toy Quack");
	}

}
